-- LT (left trigger) toggles the head flashlight, suppressed while either
-- grip (LG or RG) is held. Extracted out of ARCADE CONTROLS for RE2 VR's
-- re2_vr_holster.lua into its own standalone script -- this keeps only the
-- flashlight-toggle subsystem, none of that file's holster-position/
-- weapon-select logic.
--
-- Why LT and not the native X button: X is reused as both menu-navigation
-- and (in earlier versions of this mod) the flashlight toggle, gated on a
-- guessed list of "is a menu currently blocking this" GUI element names --
-- that list had real, repeated gaps (item box, save point/typewriter, the
-- lion-medallion puzzle all slipped through it and mis-toggled the
-- flashlight). LT isn't the native menu/back button at all, so it sidesteps
-- that whole bug class instead of needing to patch it screen-by-screen.
--
-- Why suppressed on LG/RG: LT already means something while gripping in the
-- full mod (slide-rack/pump trigger-pull mechanics), and more generally
-- it's a safety margin against incidental trigger contact while two-handing
-- or holding a sub-weapon -- an accidental flashlight toggle mid-fight is
-- exactly the annoyance this exists to prevent.

if reframework:get_game_name() ~= "re2" then
    return
end

if not vrmod then
    log.warn("[re2_vr_flashlight_toggle] vrmod not available, aborting")
    return
end

local re2 = require("utility/RE2")
local vrc_manager = require("vr/VRControllerManager")

local NS = sdk.game_namespace

local survivor_condition_type = sdk.typeof(NS("survivor.SurvivorCondition"))
local player_action_orderer_type = sdk.typeof(NS("survivor.player.PlayerActionOrderer"))
local flash_light_type = sdk.typeof(NS("FlashLight"))

local enabled = true
local flashlight_power = false
local illumination_manager = nil

local vr_flash = {
    condition = nil,
    action_orderer = nil,
    light_timer = nil,
    last_scan_frame = -9999,
    pending_pulses = 0,
    pulse_cooldown = 0,
    ready = false,
    frame = 0,
    lt_action = nil,
    lt_prev = false,
}

-- Reads a shared "block weapon inputs" flag other mods (e.g. a manual
-- reload script) may set via this global -- harmless no-op if nothing else
-- sets it, which is the expected case when this runs standalone.
local function block_weapon_inputs_active()
    return rawget(_G, "__vr_block_weapon_inputs") == true
end

local function safe_call(obj, m, ...)
    if not obj then return nil end
    local ok, a, b, c = pcall(function(...) return obj:call(m, ...) end, ...)
    if not ok then return nil end
    return a, b, c
end

local function managed_type_has_field(obj, field_name)
    if not obj or type(field_name) ~= "string" then return false end
    local ok, td = pcall(function() return obj:get_type_definition() end)
    if not ok or not td then return false end
    local ok2, f = pcall(function() return td:get_field(field_name) end)
    return ok2 and f ~= nil
end

-- set_field logs REFramework errors even inside pcall; only call when the field exists on the runtime type.
local function safe_set_managed_field(obj, field_name, value)
    if not managed_type_has_field(obj, field_name) then return false end
    local ok = pcall(function() obj:set_field(field_name, value) end)
    return ok
end

local function get_player()
    return re2.get_localplayer()
end

local function get_component_on(obj, comp_type)
    if not obj or not comp_type then return nil end
    local ok, comp = pcall(function() return obj:call("getComponent(System.Type)", comp_type) end)
    return ok and comp or nil
end

local function get_transform_children(xform)
    local out = {}
    if not xform then return out end
    local child = safe_call(xform, "get_Child")
    while child do
        out[#out + 1] = child
        child = safe_call(child, "get_Next")
    end
    return out
end

local function find_flashlight_on_transform(xform, depth)
    if not xform or (depth ~= nil and depth < 0) then return nil, nil end
    local go = safe_call(xform, "get_GameObject")
    if go and flash_light_type then
        local comp = get_component_on(go, flash_light_type)
        if comp then return go, comp end
    end
    for _, child in ipairs(get_transform_children(xform)) do
        local fgo, fcomp = find_flashlight_on_transform(child, (depth or 10) - 1)
        if fcomp then return fgo, fcomp end
    end
    return nil, nil
end

local function vr_flash_read_is_light(condition)
    if not condition then return nil end
    local ok, v = pcall(function() return condition:get_field("<IsLight>k__BackingField") end)
    if ok and v ~= nil then return v == true end
    local m = safe_call(condition, "get_IsLight")
    if m ~= nil then return m == true end
    return nil
end

local function vr_flash_set_manually_light(condition, enabled_flag)
    if not condition then return end
    pcall(function() condition:call("set_ManuallyLight", enabled_flag == true) end)
end

local function vr_flash_extend_light_timer(timer, seconds)
    if not timer or not seconds then return end
    pcall(function() timer._TimeLimit = seconds end)
    pcall(function() timer:set_field("_TimeLimit", seconds) end)
end

-- PlayerActionOrderer PrecedeBits.Accept(64) simulates the manual flashlight switch input.
local function vr_flash_pulse_toggle(action_orderer)
    if not action_orderer then return false end
    local bits = nil
    pcall(function() bits = action_orderer:get_field("<PrecedeBits>k__BackingField") end)
    if not bits then return false end
    local ok = pcall(function() bits:set_Accept(64) end)
    return ok == true
end

local function refresh_vr_flash_surfaces(force)
    vr_flash.frame = (vr_flash.frame or 0) + 1
    if not force and (vr_flash.frame - vr_flash.last_scan_frame) < 30 then
        return vr_flash.ready
    end
    vr_flash.last_scan_frame = vr_flash.frame
    vr_flash.condition = nil
    vr_flash.action_orderer = nil
    vr_flash.light_timer = nil
    vr_flash.ready = false

    local player = get_player()
    if not player then return false end

    vr_flash.action_orderer = get_component_on(player, player_action_orderer_type)
    vr_flash.condition = get_component_on(player, survivor_condition_type)

    local _, flash_comp = find_flashlight_on_transform(safe_call(player, "get_Transform"), 12)
    if flash_comp then
        local cond = nil
        pcall(function() cond = flash_comp:get_field("<Condition>k__BackingField") end)
        if cond then vr_flash.condition = cond end
    end

    if vr_flash.condition then
        vr_flash.light_timer = nil
        pcall(function() vr_flash.light_timer = vr_flash.condition:get_field("<LightSwitchTimer>k__BackingField") end)
        if not vr_flash.action_orderer then
            pcall(function()
                vr_flash.action_orderer = vr_flash.condition:get_field("<ActionOrderer>k__BackingField")
            end)
        end
    end

    vr_flash.ready = vr_flash.action_orderer ~= nil and vr_flash.condition ~= nil
    return vr_flash.ready
end

local function apply_vr_head_flashlight_fallback_illumination()
    if not illumination_manager then
        pcall(function()
            illumination_manager = sdk.get_managed_singleton(sdk.game_namespace("IlluminationManager"))
        end)
    end
    if not illumination_manager then return false end
    local on = flashlight_power and 1 or 0
    if not safe_set_managed_field(illumination_manager, "shouldUseFlashlight", on) then
        pcall(function() illumination_manager:write_uint32(0x60, on) end)
    end
    if not safe_set_managed_field(illumination_manager, "someCounter", on) then
        pcall(function() illumination_manager:write_uint32(0x64, on) end)
    end
    if managed_type_has_field(illumination_manager, "shouldUseFlashlight2") then
        safe_set_managed_field(illumination_manager, "shouldUseFlashlight2", flashlight_power == true)
    else
        pcall(function() illumination_manager:write_byte(0x68, on) end)
    end
    return true
end

local function tick_vr_flashlight_pending()
    if vr_flash.pending_pulses <= 0 then return end
    if vr_flash.pulse_cooldown > 0 then
        vr_flash.pulse_cooldown = vr_flash.pulse_cooldown - 1
        return
    end
    if not refresh_vr_flash_surfaces(false) or not vr_flash.action_orderer then
        vr_flash.pending_pulses = 0
        return
    end
    local is_light = vr_flash_read_is_light(vr_flash.condition)
    local want_on = flashlight_power == true
    if (want_on and is_light == true) or (not want_on and is_light ~= true) then
        vr_flash.pending_pulses = 0
        return
    end
    if vr_flash_pulse_toggle(vr_flash.action_orderer) then
        vr_flash.pending_pulses = vr_flash.pending_pulses - 1
        vr_flash.pulse_cooldown = 2
    else
        vr_flash.pending_pulses = 0
    end
end

local function apply_vr_head_flashlight_toggle()
    if not enabled then return end
    if not refresh_vr_flash_surfaces(true) or not vr_flash.action_orderer then
        apply_vr_head_flashlight_fallback_illumination()
        return
    end

    local want_on = flashlight_power == true
    local is_light = vr_flash_read_is_light(vr_flash.condition)

    if want_on then
        vr_flash_set_manually_light(vr_flash.condition, true)
        vr_flash_extend_light_timer(vr_flash.light_timer, 999.0)
        if is_light ~= true then
            vr_flash_pulse_toggle(vr_flash.action_orderer)
            vr_flash.pending_pulses = 12
            vr_flash.pulse_cooldown = 0
        end
    else
        vr_flash_set_manually_light(vr_flash.condition, false)
        if is_light ~= false then
            vr_flash_pulse_toggle(vr_flash.action_orderer)
            vr_flash.pending_pulses = 12
            vr_flash.pulse_cooldown = 0
        end
    end
end

local function maintain_vr_head_flashlight_state()
    if not enabled then return end
    tick_vr_flashlight_pending()
    if not flashlight_power then return end
    if not refresh_vr_flash_surfaces(false) or not vr_flash.condition then return end
    vr_flash_set_manually_light(vr_flash.condition, true)
end

local function get_left_joystick()
    if not vrmod then return nil end
    if vrc_manager:has_controllers() then
        local lc = vrc_manager.controllers_list[1]
        if lc and lc.joystick then return lc.joystick end
    end
    local lj = nil
    pcall(function() lj = vrmod:get_left_joystick() end)
    if lj then return lj end
    local ok, val = pcall(vrmod.get_left_joystick, vrmod)
    return ok and val or nil
end

local function is_left_grip_pressed()
    if not vrmod then return false end
    if vrc_manager:has_controllers() then
        local lc = vrc_manager.controllers_list[1]
        if lc then
            return lc:is_action_active(vrc_manager.Actions.GRIP) == true
        end
    end
    local lj = get_left_joystick()
    if not lj then return false end
    local action = nil
    pcall(function() action = vrmod:get_action_grip() end)
    if not action then return false end
    local ok, v = pcall(function() return vrmod:is_action_active(action, lj) end)
    return ok and v == true
end

local function is_right_grip_pressed()
    if not vrmod then return false end
    if vrc_manager:has_controllers() then
        local rc = vrc_manager.controllers_list[2]
        if rc then
            return rc:is_action_active(vrc_manager.Actions.GRIP) == true
        end
    end
    -- No cached right joystick object here (this file never needs it for
    -- anything else) -- fetch it directly, mirroring get_left_joystick.
    local rj = nil
    pcall(function() rj = vrmod:get_right_joystick() end)
    if not rj then
        local ok, val = pcall(vrmod.get_right_joystick, vrmod)
        rj = ok and val or nil
    end
    if not rj then return false end
    local action = nil
    pcall(function() action = vrmod:get_action_grip() end)
    if not action then return false end
    local ok, v = pcall(function() return vrmod:is_action_active(action, rj) end)
    return ok and v == true
end

re.on_frame(function()
    if not enabled then return end

    if not vr_flash.lt_action or vr_flash.lt_action == 0 then
        pcall(function() vr_flash.lt_action = vrmod:get_action_trigger() end)
    end
    local lj_lt = get_left_joystick()
    local lt_down = false
    if vr_flash.lt_action and lj_lt then
        local ok_lt, active = pcall(function()
            return vrmod:is_action_active(vr_flash.lt_action, lj_lt)
        end)
        lt_down = ok_lt and active == true
    end
    local lt_suppressed = is_left_grip_pressed() or is_right_grip_pressed()
        or block_weapon_inputs_active()

    if lt_down and not vr_flash.lt_prev and not lt_suppressed then
        flashlight_power = not flashlight_power
        apply_vr_head_flashlight_toggle()
    end
    vr_flash.lt_prev = lt_down

    maintain_vr_head_flashlight_state()
end)

re.on_draw_ui(function()
    if not imgui then return end
    imgui.text("Flashlight toggle: LT, suppressed while LG or RG held")
    local c, v = imgui.checkbox("Enabled", enabled)
    if c then enabled = v end
    imgui.text("Flashlight is currently: " .. (flashlight_power and "ON" or "off"))
end)

log.info("[re2_vr_flashlight_toggle] Loaded")
