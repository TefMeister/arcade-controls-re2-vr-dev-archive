WHAT IS THIS MOD YOU ASK?

A small standalone slice of "ARCADE CONTROLS for RE2 VR" -- just the grip
input discipline, without any of that mod's holster repositioning, weapon
selection remap, or reload gestures.

what it does:

- holding RG (right grip) keeps the sub-weapon (knife/grenade/flashbang)
  from popping into your hand -- so two-handing your main weapon never gets
  interrupted. Only LG stays available for an actual grab.
- holding either grip (LG or RG) blocks the LT flashlight toggle, so you
  can't accidentally flick the flashlight on/off while gripping something.
- LG-then-RG is still recognized as throwing a grenade (or whatever's
  readied in the off-hand) and is NOT suppressed -- only a plain RG-first
  two-handing grab is. This is decided by which grip you pressed first, so
  grenade throws keep working normally.

what this does NOT include (on purpose, left out of this standalone cut):
- the RG+LG+LT slide-rack/pump reload gesture
- weapon holster repositioning
- weapon-select remapping (RThumb+LS etc.)
- movement/speed changes

if you already use "ARCADE CONTROLS for RE2 VR", you already have all of
this -- no need to install both.


important -- controller bindings:

this mod only uses the default Grip and Trigger actions (the same ones any
stock REFramework VR setup already has bound to the physical grip and
trigger). It does NOT ship or need a custom
_interaction_profiles_oculus_touch_controller.json. If you have a
customized controller-profile json installed from elsewhere (e.g. the full
ARCADE CONTROLS mod, which remaps other inputs like weapon selection),
make sure Grip and Trigger are still bound to their default meaning, or
this mod's suppression logic and flashlight toggle won't trigger off the
physical buttons you expect. Simplest: use this mod on a game/REFramework
setup with default/stock controller bindings.


installation:

1. install praydog's REFramework (required for any RE2 VR/Lua mod).
2. install this mod with Fluffy Mod Manager, or manually copy the
   "reframework" folder from this zip into your game's root folder.
3. start the game, open the REFramework overlay, find ScriptRunner and click
   "Reset Scripts" if the feature doesn't seem to be active yet.


credits:

Built as part of "ARCADE CONTROLS for RE2 VR" (a fork of Andyalpa's
RE2VRMODRELOADED), by TefMeister and Claude code, then split out as its own
release. If you like this, check out the full mod and consider supporting
Andyalpa, whose original mod this project is built on top of:
https://ko-fi.com/andyalpa
https://www.nexusmods.com/residentevil22019/mods/2483
