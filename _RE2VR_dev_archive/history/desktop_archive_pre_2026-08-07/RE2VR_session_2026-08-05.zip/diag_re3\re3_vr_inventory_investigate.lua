-- One-pass investigation of RE3's item-pickup inventory flow, comparing
-- against RE2's already-fully-mapped equivalent.
--
-- Confirmed so far: RE3's GUIMaster lives under "offline.gui.GUIMaster"
-- (RE2 uses "app.ropeway.gui.GUIMaster"). The pickup trigger method name
-- is IDENTICAL to RE2 (GUIMaster.openInventoryGetItemMode), plus an extra
-- call RE2 doesn't have (GUIMaster.drawGetItemInfo). User confirmed live:
-- in RE3, a single button press sends the item straight into inventory --
-- no grid-navigation/slot-placement screen required, unlike RE2's
-- multi-step flow. Goal now: find RE3's real inventory-UI component
-- name(s) (RE2's class name "NewInventoryBehavior" does not exist in RE3)
-- by enumerating actual attached components, not guessing more names.
--
-- Purely passive: hooks methods only to LOG calls, never skips/alters
-- anything, never writes fields.
--
-- Fix vs. the previous version: GUIMaster's singleton isn't always ready
-- the instant this script loads (game-dependent init timing) -- this
-- retries setup every frame until it succeeds, instead of trying once and
-- giving up if the singleton wasn't registered yet.

local game = reframework:get_game_name()
if game ~= "re3" then
    log.warn("[re3_investigate] unexpected game name: " .. tostring(game) .. " (expected re3)")
end

local NS = sdk.game_namespace

local function log_line(s)
    log.info("[re3_investigate] " .. s)
end

log_line("Game detected as: " .. tostring(game))

local gm_type = NS("gui.GUIMaster")
log_line("Trying GUIMaster namespace: " .. tostring(gm_type))

local hooks_installed = false
local hooked_count = 0
local pickup_pending_frames = 0
local dumped = false

local function dump_type_methods_and_fields(obj, label)
    if not obj then
        log_line(label .. ": object is nil")
        return
    end
    local ok_td, td = pcall(function() return obj:get_type_definition() end)
    if not ok_td or not td then
        log_line(label .. ": could not get type definition")
        return
    end
    local ok_full, full_name = pcall(function() return td:get_full_name() end)
    log_line(label .. " type: " .. tostring(ok_full and full_name or "?"))

    local ok_m, methods = pcall(function() return td:get_methods() end)
    if ok_m and methods then
        for _, m in ipairs(methods) do
            local ok_n, mname = pcall(function() return m:get_name() end)
            if ok_n and mname then
                log_line("  method: " .. mname)
            end
        end
    end

    local ok_f, fields = pcall(function() return td:get_fields() end)
    if ok_f and fields then
        for _, f in ipairs(fields) do
            local ok_n, fname = pcall(function() return f:get_name() end)
            if ok_n and fname then
                local ok_static, is_static = pcall(function() return f:is_static() end)
                local ok_v, value
                if ok_static and is_static then
                    ok_v, value = pcall(function() return f:get_data(nil) end)
                else
                    ok_v, value = pcall(function() return f:get_data(obj) end)
                end
                log_line(string.format("  field: %s = %s", fname, tostring(ok_v and value or "?(get_data failed)")))
            end
        end
    end
end

local function try_dump_behavior()
    if dumped then return end
    local gui_master = sdk.get_managed_singleton(gm_type)
    if not gui_master then return end
    local ok_go, inv_go = pcall(function() return gui_master:get_field("RefInventoryUI") end)
    if not ok_go or not inv_go then
        log_line("RefInventoryUI field not found/failed on GUIMaster this attempt (will retry on next pickup)")
        return
    end

    local ok_comps, comps_list = pcall(function()
        return inv_go:call("get_Components"):get_elements()
    end)
    if not ok_comps or not comps_list then
        log_line("Could not enumerate components on RefInventoryUI GameObject this attempt (will retry)")
        return
    end

    dumped = true
    log_line("========================================")
    log_line(string.format("RefInventoryUI has %d component(s):", #comps_list))
    local inventory_like = {}
    for _, comp in ipairs(comps_list) do
        local ok_td, td = pcall(function() return comp:get_type_definition() end)
        if ok_td and td then
            local ok_name, full_name = pcall(function() return td:get_full_name() end)
            local name = ok_name and full_name or "?"
            log_line("  component: " .. name)
            if name:lower():find("inventory") then
                table.insert(inventory_like, { comp = comp, name = name })
            end
        end
    end

    log_line("---- Dumping components with 'inventory' in the name ----")
    for _, entry in ipairs(inventory_like) do
        dump_type_methods_and_fields(entry.comp, entry.name)
    end
    log_line("========================================")
end

local function try_setup_hooks()
    if hooks_installed then return end
    local gm = sdk.get_managed_singleton(gm_type)
    if not gm then return end

    hooks_installed = true
    log_line("GUIMaster singleton found (after retrying).")

    local ok_td, td = pcall(function() return gm:get_type_definition() end)
    if not ok_td or not td then
        log_line("Could not get GUIMaster type definition")
        return
    end
    local ok_full, full_name = pcall(function() return td:get_full_name() end)
    log_line("GUIMaster actual type name: " .. tostring(ok_full and full_name or "?"))

    local ok_m, methods = pcall(function() return td:get_methods() end)
    if ok_m and methods then
        for _, m in ipairs(methods) do
            local ok_n, mname = pcall(function() return m:get_name() end)
            if ok_n and mname then
                local lower = mname:lower()
                if lower:find("inventory") or lower:find("getitem") then
                    local ok_h = pcall(function()
                        sdk.hook(m,
                            function(args)
                                log_line(string.format("GUIMaster.%s CALLED (os.clock=%.3f)", mname, os.clock()))
                                if lower:find("getitem") then
                                    pickup_pending_frames = 5
                                end
                                return sdk.PreHookResult.CALL_ORIGINAL
                            end,
                            function(retval) return retval end)
                    end)
                    if ok_h then hooked_count = hooked_count + 1 end
                end
            end
        end
    end
    log_line(string.format("Hooked %d GUIMaster method(s) matching inventory/getitem.", hooked_count))
end

re.on_frame(function()
    if not hooks_installed then
        pcall(try_setup_hooks)
        return
    end
    if dumped then return end
    if pickup_pending_frames > 0 then
        pickup_pending_frames = pickup_pending_frames - 1
        if pickup_pending_frames == 0 then
            pcall(try_dump_behavior)
        end
    end
end)

re.on_draw_ui(function()
    if not imgui then return end
    imgui.text_colored(
        "Passive only. Pick up an item in RE3 normally, then check re2_framework_log.txt (RE3's own log file) for [re3_investigate] lines.",
        0xFF88CCFF)
    imgui.text("Hooks installed: " .. tostring(hooks_installed))
    imgui.text("Hooked inventory/getitem methods: " .. tostring(hooked_count))
    imgui.text("Behavior dumped yet: " .. tostring(dumped))
    if imgui.button("Force dump attempt now") then
        pcall(try_dump_behavior)
    end
    if imgui.button("Reset (allow dumping again)") then
        dumped = false
    end
end)

log_line("Loaded")
