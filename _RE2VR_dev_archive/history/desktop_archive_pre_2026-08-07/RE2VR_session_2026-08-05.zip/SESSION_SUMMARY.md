# RE2 VR Mod — Full Session Summary (2026-08-05)

## Where files go

**`mod/` → merge into the ArcadeControlsVR mod package**
(both the live RE2 game's `reframework\` folder AND the FMM-staged copy at
`FluffyModManager\games\RE2\mods\ArcadeControlsVR\reframework\` — keep both
in sync):
- `mod/utility/RE2Character.lua` → `reframework/autorun/utility/RE2Character.lua`
- `mod/re2_vr_reload.lua` → `reframework/autorun/re2_vr_reload.lua`
- `mod/data/re2_vr_reload.json` → `reframework/data/re2_vr/re2_vr_reload.json`

**`diag_re2/` → loose RE2 diagnostic scripts, not part of the packaged mod**
Drop directly into the live RE2 game's `reframework\autorun\`:
- `re2_vr_posture_twist_probe.lua`
- `re2_vr_posture_spine_straighten_override.lua` (the working torso-straighten fix)
- `re2_vr_inventory_behavior_dump.lua`
- `re2_vr_inventory_open_hook_probe.lua`

**`diag_re3/` → RE3 diagnostic script**
Drop into RE3's `reframework\autorun\` (needs REFramework installed —
just copy `dinput8.dll` from the RE2 install, same monolithic build works
for both games):
- `re3_vr_inventory_investigate.lua`

## What happened this session

### 1. Fixed a real bug: Claire's character detection (`RE2Character.lua`)
`RE2_PL_MAP` assumed Claire's live GameObject name was `pl0100`; it's
actually `pl1000`. Silently made Claire's holster-position tuning share
Leon's profile bucket instead of her own. Fixed the map key and two
string-prefix fallback checks. First live-tested this session when the
mod was actually installed (see #4).

### 2. Torso-twist investigation (Claire/Jill VR body-presence jank) — BREAKTHROUGH, then paused on a follow-up issue
Goal: Claire's torso visibly twists ~40° in VR during weapon holds. Three
approaches tried:

1. **Raw `.motlist` file swap** — FAILED (skeleton-specific binary data,
   not portable between characters).
2. **Weapon-category spoof** (`Equipment.ForceEquipType`) — FAILED, confirmed
   via live data: spoofing to Anti-Tank Rocket didn't reproduce its real
   spine value AND visually swapped in the actual rocket-launcher model.
3. **Direct spine-bone override** (`re2_vr_posture_spine_straighten_override.lua`)
   — **WORKS.** Directly overwrites `spine_0`'s local rotation every
   `LateUpdateBehavior` tick, bypassing animation-selection entirely.
   **Confirmed live at strength=1.0 (flat-screen only, no VR access yet):
   torso visibly straightens.** First real win after two dead ends.

   **Unresolved side effect:** with strength=1.0, the pistol/laser sight
   visually point left, even though bullets still fire straight (aim is
   controller-driven, confirmed good). Tried both a "Pre" and "Post" hook
   timing (relative to arm IK solving) — **neither fixed it**, so it's not
   simple frame-ordering. Script has both options, switchable live via a
   selector, no relaunch needed to compare.

   **Next things to try (not yet attempted):** check if arm-aim IK reads a
   different joint than spine_0 (spine_1/spine_2/pelvis); try a
   compensating counter-rotation on the arm/hand chain directly; check if
   the IK caches across multiple frames rather than fully re-solving.
   **Priority: test in actual VR, not just flat-screen** — this was the
   explicit reason the sub-investigation paused here.

   Once solved: productize into the actual mod (currently a loose
   diagnostic script) with character gating (Claire/Ada/Jill, not Leon)
   and a config toggle/strength setting.

### 3. Extended trigger-driven slide-rack reload gesture to more pistols
Was already working on 4 weapons (Matilda, Broom Hc/Ada, Lightning Hawk,
W-870 shotgun). An Explore agent confirmed the gesture is a generic,
config-flag-gated state machine, not per-weapon bespoke code — all 5
shotgun IDs were already fully wired, just untested beyond W-870.

**Change made** (in `mod/re2_vr_reload.lua` + `mod/data/re2_vr_reload.json`
in this zip): flipped `trigger_slide_rack = true` for M19, JMB Hp3,
Glock 17, MUP, and the Samurai Edge base skin.

**Explicitly excluded:** MQ 11 and LE 5 (submachine guns) — user found
LE 5's reload animation is different from the pistols', wants to handle
these separately with real playtesting, not batched blind.

**Not yet done:** in-game feel-verification of the 5 newly-flipped
pistols, and confirming the 4 untested shotgun IDs work like W-870.

### 4. Installed the mod for the first time this session
Mod wasn't actually deployed into the live game at session start. Also
discovered it's pure REFramework content (no `natives\` asset files) —
doesn't need Fluffy Mod Manager's pak-invalidation mechanism, just a
direct file copy into `reframework\`.

### 5. Item-pickup "skip inventory screen" feature — PAUSED after 6 failed live attempts
Goal: skip the native "Got [item]" → full inventory-grid placement screen
so items just go straight into inventory. **Six consecutive failed live
attempts, in order:**
1. Skipping `GUIMaster.openInventoryGetItemMode` entirely — **real item
   loss** (ammo vanished from world, never landed in inventory).
2. Simulating `PlayerActionOrderer.PrecedeBits.Accept(64)` as a "confirm"
   input (copied from the flashlight-toggle script) — wrong assumption,
   that bit is hardcoded to the flashlight action specifically, not a
   generic menu confirm. Did nothing for the screen, toggled the
   flashlight instead.
3. Setting `DetailBehavior.IsFinish = true` directly — **hung the entire
   game**, required a force-close. (No progress lost — user's using this
   RE2 install purely for testing, crashes are fine.)
4. Setting `SlotBehavior.IsCloseGetItemMode = true` — no-op, silently
   ruled out via passive setter-scan (confirmed neither this nor any other
   plausible "done" flag ever fires during 2 real normal pickups).
5. Calling `NewInventoryBehavior.finish()` directly — no-op (it's the
   LAST step of the real chain, nothing to finish when called standalone).
6. Calling `SlotBehavior.exchangeGetItem()` directly (the real first
   trigger, found by passively observing 2 full real pickups) — also a
   no-op, meaning it depends on cursor/slot-selection state built up by
   real per-frame input handling, not something a single out-of-context
   call can substitute for.

**The real completion sequence WAS fully mapped** (from passive
observation, no guessing): `SlotBehavior.exchangeGetItem()` →
`SlotBehavior.setSlotItem()` → `DetailBehavior.close()` → *(~300ms gap)*
→ `NewInventoryBehavior.close()` → `SlotBehavior.close()` →
`DetailBehavior.forceClose()` → `mainPanelStateFinished()` →
`NewInventoryBehavior.finish()`.

**Paused, user's explicit choice** — the real fix needs simulating actual
cursor-navigation input across multiple frames (driving the selection to
a valid slot before a confirm-equivalent call), a bigger task than
anything else attempted. All risky diagnostic scripts were deleted as
each lead got ruled out; only two harmless passive ones remain
(`re2_vr_inventory_behavior_dump.lua`, `re2_vr_inventory_open_hook_probe.lua`,
both in `diag_re2/` in this zip).

### 6. RE3 comparison — settled a related question conclusively
User installed RE3 (2020 remake) specifically to check whether it handles
item pickup differently (recalled it not showing the full screen every
time). Set up REFramework for RE3 by copying the core `dinput8.dll`
loader directly from the already-working RE2 install (confirmed identical
monolithic build, same commit hash — no download needed).

**Confirmed via live reflection:** RE3's pickup UI class is
`offline.gui.EsInventoryBehavior` (RE2's class name `NewInventoryBehavior`
doesn't exist in RE3 at all — different namespace family, `offline.*` vs
`app.ropeway.*`). **RE3 has a method RE2 genuinely does not have at all:
`openGetItemMode_Type02`** — cross-checked against RE2's full method dump,
confirmed absent. RE3 also has extra state getters RE2 lacks
(`get_IsItemGetMode`, `get_IsItemGetModeDetailSearch`, etc.), consistent
with a real second, faster pickup-mode implementation existing alongside
the original one.

**This settles the open question:** RE3's single-button "item vanishes
straight into inventory" behavior (user-confirmed live) is a genuine
Capcom engine addition in RE3 — not something RE2 already secretly
supports. There's no shortcut to borrow for RE2; if it's ever built there,
it has to be the harder navigation-simulation approach from #5, not a
different method call.

## Open threads for next session
1. **Priority: test spine-straighten override in real VR**, both hook
   timings, see if the pointing-left issue reads the same as flat-screen.
   If still broken: try a different joint (spine_1/2/pelvis) or a
   compensating counter-rotation on the arm/hand chain.
2. Feel-test the 5 newly-flipped pistols + verify remaining 4 shotgun IDs
   for the slide-rack/pump gesture.
3. MQ 11 / LE 5 reload gesture — investigate what's different about
   LE 5's animation before assuming the flag flip will work.
4. Confirm the `RE2Character.lua` pl1000 fix didn't break anything.
5. Item-pickup feature (paused): if resumed, the real completion sequence
   is already fully mapped (see #5 above) — the remaining work is
   simulating real cursor-navigation input across frames, not finding a
   different single method/flag to call. No shortcut exists via RE3
   either (see #6).
6. (Deferred, not urgent) Real animation retargeting via 3ds Max +
   RevilMax + Motlist Tool remains the fallback for full pose unification
   if the direct-override approach hits a wall for the VR aim issue —
   user wants to try the 30-day 3ds Max trial "sometime in the future,"
   not now.
