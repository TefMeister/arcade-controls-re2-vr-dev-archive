-- Diagnostic: auto-hooks every method on gui.GUIMaster whose name mentions
-- "inventory" (case-insensitive), logging each call with a timestamp. Goal:
-- catch exactly which native method fires when an item pickup auto-opens
-- the full inventory grid screen, vs. what fires when the player manually
-- opens inventory via the menu button -- so we can eventually hook/block
-- just the pickup-triggered path.
--
-- Confirmed via re2_vr_gui_state_probe.lua: the screen the user sees IS the
-- native GUIMaster inventory-open state (state 0->1, get_IsOpenInventory
-- true) -- not something introduced by this mod's own scripts.

if reframework:get_game_name() ~= "re2" then
    return
end

local NS = sdk.game_namespace

local log_buffer = {}
local MAX_LOG_LINES = 100

local function log_line(s)
    log.info("[inv_open_hook_probe] " .. s)
    table.insert(log_buffer, 1, "[inv_open_hook_probe] " .. s)
    if #log_buffer > MAX_LOG_LINES then table.remove(log_buffer) end
end

local hooked_count = 0

local function install_hooks()
    local td = sdk.find_type_definition(NS("gui.GUIMaster"))
    if not td then
        log_line("could not find type gui.GUIMaster")
        return
    end

    local ok_m, methods = pcall(function() return td:get_methods() end)
    if not ok_m or not methods then
        log_line("could not get methods on GUIMaster")
        return
    end

    for _, m in ipairs(methods) do
        local ok_n, mname = pcall(function() return m:get_name() end)
        if ok_n and mname and mname:lower():find("inventory") then
            local ok_h = pcall(function()
                sdk.hook(m,
                    function(args)
                        log_line(string.format("CALLED: GUIMaster.%s  (os.clock=%.3f)", mname, os.clock()))
                    end,
                    function(retval)
                        return retval
                    end)
            end)
            if ok_h then
                hooked_count = hooked_count + 1
                log_line("hooked: " .. mname)
            else
                log_line("FAILED to hook: " .. mname)
            end
        end
    end

    log_line(string.format("Done. %d method(s) hooked.", hooked_count))
end

install_hooks()

re.on_draw_ui(function()
    if not imgui then return end
    imgui.text_colored(
        string.format("%d GUIMaster.*Inventory* method(s) hooked. Pick up an item, then check which one fired.", hooked_count),
        0xFF88CCFF)
    if imgui.button("Clear log") then
        log_buffer = {}
    end
    for _, line in ipairs(log_buffer) do
        imgui.text(line)
    end
end)

log.info("[re2_vr_inventory_open_hook_probe] Loaded")
