-- Recreated diagnostic (original built 2026-08-04/05, deleted/lost between
-- sessions -- see RE2-VR-Posture-Unification-Handoff.md "Update 2"). Gives
-- objective numbers for the torso-twist investigation instead of relying on
-- eyeballing the model, since flat-screen comparisons ("does she look
-- different holding a shotgun vs. a pistol?") turned out too subtle to call
-- by eye alone.
--
-- Full 91-component inventory + per-component field dump from the original
-- session is already written up in the handoff doc -- not repeated here.
-- This version is narrower and reusable: one button, snapshots the numbers
-- that actually matter (spine/pelvis/neck/head joint rotation + the known
-- SurvivorBuriedArmCorrector field) every time you click it, so you can
-- snapshot with one weapon equipped, snapshot again with another, and diff
-- the printed numbers directly in re2_framework_log.txt.

if reframework:get_game_name() ~= "re2" then
    return
end

local re2 = require("utility/RE2")
local NS = sdk.game_namespace

local JOINT_NAMES = { "pelvis", "spine_0", "spine_1", "spine_2", "neck", "head" }

local function get_component(go, type_name)
    if not go then return nil end
    local t = sdk.typeof(type_name)
    if not t then return nil end
    local ok, c = pcall(function() return go:call("getComponent(System.Type)", t) end)
    return ok and c or nil
end

local function try_call_vec3(obj, methods)
    for _, m in ipairs(methods) do
        local ok, v = pcall(function() return obj:call(m) end)
        if ok and v and type(v.x) == "number" then return v, m end
    end
    return nil, nil
end

local function try_call_quat(obj, methods)
    for _, m in ipairs(methods) do
        local ok, v = pcall(function() return obj:call(m) end)
        if ok and v and type(v.x) == "number" and type(v.w) == "number" then return v, m end
    end
    return nil, nil
end

local function fmt_vec3(v)
    if not v then return "n/a" end
    return string.format("(%.4f, %.4f, %.4f)", v.x, v.y, v.z)
end

local function fmt_quat(q)
    if not q then return "n/a" end
    return string.format("(%.4f, %.4f, %.4f, %.4f)", q.x, q.y, q.z, q.w)
end

local function get_current_weapon_info(player)
    local equipment = get_component(player, NS("survivor.Equipment"))
    if not equipment then return "no Equipment component" end
    local ok_arm, arm = pcall(function() return equipment:call("get_MainWeapon") end)
    if not ok_arm or not arm then return "no MainWeapon (bare hands?)" end
    local ok_wt, wt = pcall(function() return arm:get_field("_WeaponType") end)
    if not ok_wt or wt == nil then return "MainWeapon present, WeaponType unreadable" end
    local ok_s, s = pcall(function() return wt:call("ToString") end)
    return ok_s and s or tostring(wt)
end

local function log_arm_correct(player, tag)
    local comp = get_component(player, NS("survivor.SurvivorBuriedArmCorrector"))
    if not comp then
        log.info("[posture_twist_probe] " .. tag .. ": SurvivorBuriedArmCorrector not found")
        return
    end
    local ok_q, q = pcall(function() return comp:get_field("<RightArmCorrectRotation>k__BackingField") end)
    if ok_q and q and type(q.x) == "number" then
        log.info("[posture_twist_probe] " .. tag .. " RightArmCorrectRotation = " .. fmt_quat(q))
    else
        log.info("[posture_twist_probe] " .. tag .. ": could not read RightArmCorrectRotation")
    end
end

local function dump_posture_snapshot()
    local player = re2.get_localplayer()
    if not player then
        log.info("[posture_twist_probe] no local player")
        return
    end

    local ok_name, name = pcall(function() return player:call("get_Name") end)
    name = (ok_name and name) or "?"
    local weapon_info = get_current_weapon_info(player)

    log.info("========================================")
    log.info(string.format("[posture_twist_probe] SNAPSHOT player=%s weapon=%s", tostring(name), tostring(weapon_info)))

    local ok_tf, tf = pcall(function() return player:call("get_Transform") end)
    if not ok_tf or not tf then
        log.info("[posture_twist_probe] no Transform on player")
        return
    end

    for _, joint_name in ipairs(JOINT_NAMES) do
        local ok_j, joint = pcall(function() return tf:call("getJointByName", joint_name) end)
        if ok_j and joint then
            local pos = nil
            do
                local ok_p, p = pcall(function() return joint:call("get_Position") end)
                if ok_p then pos = p end
            end
            local world_rot, world_m = try_call_quat(joint, { "get_WorldRotation", "get_Rotation" })
            local local_rot, local_m = try_call_quat(joint, { "get_LocalRotation" })
            log.info(string.format(
                "[posture_twist_probe]   %-10s pos=%s  world_rot%s=%s  local_rot%s=%s",
                joint_name,
                fmt_vec3(pos),
                world_m and ("[" .. world_m .. "]") or "",
                fmt_quat(world_rot),
                local_m and ("[" .. local_m .. "]") or "",
                fmt_quat(local_rot)))
        else
            log.info("[posture_twist_probe]   " .. joint_name .. ": joint not found")
        end
    end

    log_arm_correct(player, "SNAPSHOT")
    log.info("========================================")
end

re.on_draw_ui(function()
    if not imgui then return end
    imgui.text_colored(
        "Click while playing to log spine/pelvis/neck/head joint rotations + arm-correct value to re2_framework_log.txt.",
        0xFF88CCFF)
    imgui.text("Snapshot with one weapon equipped, then again with another, and diff the numbers.")
    if imgui.button("Dump Posture Snapshot") then
        dump_posture_snapshot()
    end
end)

log.info("[re2_vr_posture_twist_probe] Loaded")
