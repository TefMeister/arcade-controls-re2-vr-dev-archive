-- Diagnostic (passive only -- no input simulation, no hooks that skip or
-- alter anything): dumps the full method list of gui.NewInventoryBehavior
-- (the actual inventory UI logic class, per utility/RE2.lua's
-- RE2.get_inventory_gui_behavior()) the first time the item-get screen
-- opens, so we can find the REAL "confirm slot placement" method by name
-- instead of guessing at raw input simulation again.
--
-- Background: two prior attempts on this feature both failed live --
-- skipping GUIMaster.openInventoryGetItemMode caused real item loss, and
-- simulating PlayerActionOrderer's PrecedeBits.Accept(64) (copied from the
-- flashlight-toggle script, wrongly assumed to be a generic menu-confirm
-- input) did nothing for the screen and instead toggled Claire's
-- flashlight once focus returned to gameplay. Neither approach touched the
-- inventory UI's own logic directly -- this dump is step one of doing that
-- properly.

if reframework:get_game_name() ~= "re2" then
    return
end

local re2 = require("utility/RE2")
local NS = sdk.game_namespace

local dumped = false

local function dump_type_methods_and_fields(obj, label)
    if not obj then
        log.info("[inv_behavior_dump] " .. label .. ": object is nil")
        return
    end
    local ok_td, td = pcall(function() return obj:get_type_definition() end)
    if not ok_td or not td then
        log.info("[inv_behavior_dump] " .. label .. ": could not get type definition")
        return
    end

    local depth = 0
    while td and depth < 4 do
        local ok_name, full_name = pcall(function() return td:get_full_name() end)
        log.info(string.format("[inv_behavior_dump] %s L%d type: %s", label, depth, tostring(ok_name and full_name or "?")))

        local ok_m, methods = pcall(function() return td:get_methods() end)
        if ok_m and methods then
            for _, m in ipairs(methods) do
                local ok_n, mname = pcall(function() return m:get_name() end)
                if ok_n and mname then
                    log.info(string.format("[inv_behavior_dump]   [L%d] method: %s", depth, mname))
                end
            end
        end

        local ok_f, fields = pcall(function() return td:get_fields() end)
        if ok_f and fields then
            for _, f in ipairs(fields) do
                local ok_n, fname = pcall(function() return f:get_name() end)
                if ok_n and fname then
                    local ok_static, is_static = pcall(function() return f:is_static() end)
                    local ok_v, value
                    if ok_static and is_static then
                        ok_v, value = pcall(function() return f:get_data(nil) end)
                    else
                        ok_v, value = pcall(function() return f:get_data(obj) end)
                    end
                    log.info(string.format("[inv_behavior_dump]   [L%d] field: %s = %s",
                        depth, fname, tostring(ok_v and value or "?(get_data failed)")))
                end
            end
        end

        local ok_p, parent = pcall(function() return td:get_parent_type() end)
        if not ok_p or not parent then break end
        td = parent
        depth = depth + 1
    end
end

local function do_dump()
    if dumped then return end
    dumped = true

    log.info("========================================")
    log.info("[inv_behavior_dump] Item-get screen opened -- dumping NewInventoryBehavior")

    local ok_beh, behavior = pcall(function() return re2.get_inventory_gui_behavior() end)
    if ok_beh and behavior then
        dump_type_methods_and_fields(behavior, "NewInventoryBehavior")

        -- finish() on NewInventoryBehavior itself was tried live and had no
        -- visible effect -- the real "confirm slot"/"advance past this
        -- screen" method more likely lives on one of these two sub-behavior
        -- components instead.
        local ok_slot, slot_behavior = pcall(function()
            return behavior:get_field("<SlotBehavior>k__BackingField")
        end)
        if ok_slot and slot_behavior then
            dump_type_methods_and_fields(slot_behavior, "SlotBehavior")
        else
            log.info("[inv_behavior_dump] SlotBehavior field read failed or nil")
        end

        local ok_detail, detail_behavior = pcall(function()
            return behavior:get_field("<DetailBehavior>k__BackingField")
        end)
        if ok_detail and detail_behavior then
            dump_type_methods_and_fields(detail_behavior, "DetailBehavior")
        else
            log.info("[inv_behavior_dump] DetailBehavior field read failed or nil")
        end
    else
        log.info("[inv_behavior_dump] re2.get_inventory_gui_behavior() returned nil")
    end

    log.info("========================================")
end

local td = sdk.find_type_definition(NS("gui.GUIMaster"))
if td then
    local m = td:get_method("openInventoryGetItemMode")
    if m then
        sdk.hook(m,
            function(args)
                -- Defer slightly: dump on the next frame so the behavior
                -- component has actually been assigned/activated by then.
                rawset(_G, "__vr_inv_dump_pending", true)
                return sdk.PreHookResult.CALL_ORIGINAL
            end,
            function(retval) return retval end)
    else
        log.warn("[inv_behavior_dump] could not find openInventoryGetItemMode")
    end
else
    log.warn("[inv_behavior_dump] could not find gui.GUIMaster")
end

local pending_frames = 0
re.on_frame(function()
    if rawget(_G, "__vr_inv_dump_pending") == true then
        pending_frames = pending_frames + 1
        if pending_frames >= 5 then
            rawset(_G, "__vr_inv_dump_pending", false)
            pending_frames = 0
            do_dump()
        end
    end
end)

re.on_draw_ui(function()
    if not imgui then return end
    imgui.text_colored(
        "Passive only -- pick up an item, then check re2_framework_log.txt for [inv_behavior_dump] output.",
        0xFF88CCFF)
    imgui.text("Dumped yet: " .. tostring(dumped))
    if imgui.button("Reset (dump again on next pickup)") then
        dumped = false
    end
end)

log.info("[re2_vr_inventory_behavior_dump] Loaded")
